

//Abrir e fechar menu lateral
function menuShow() {
    let menuMobile = document.querySelector('.menu-lateral');
    menuMobile.classList.toggle("open");
    let menuOverlay = document.querySelector('.menu-overlay');
    menuOverlay.classList.toggle("open");
}

function menuClose() {
    let menuMobile = document.querySelector('.menu-lateral');
    menuMobile.classList.toggle("open");
    let menuOverlay = document.querySelector('.menu-overlay');
    menuOverlay.classList.toggle("open");
}

//funcao de sair do menu lateral ao apertar a tecla ESC
document.addEventListener('keydown', function (evento) {
    // Verifica se a tecla pressionada é 'Esc'
    if (evento.key === 'Escape' || evento.keyCode === 27) {
        // Verifica se o overlay está visível antes de tentar fechar
        const overlay = document.querySelector('.menu-overlay');
        if (overlay.classList.contains('open')) {
            menuClose();
        }
    }
});

//modo escuro e claro
/*const radios = document.getElementsByName('tema');

radios.forEach(radio => {
    radio.addEventListener('change', () => {
        let homePage = document.querySelector(".home-page");
        let content = document.querySelector(".text-content"); 
        let denunciaPage = document.querySelector(".denuncia-page");

        if (radio.value == 'dark') {
            if(homePage){//testar depois o porque do .dark so exibir no h1 e nos outros nao no dom

                homePage.classList.add("dark");
                homePage.classList.remove("light");
                content.classList.add("dark");
                content.classList.remove("light");
            }
            
            if(denunciaPage){
                denunciaPage.classList.add("dark");
                denunciaPage.classList.remove("light");
                content.classList.add("dark");
                content.classList.remove("light");
            }
            
        }
        if (radio.value == 'light') {
            if(homePage){
                homePage.classList.add("light");
                homePage.classList.remove("dark");
                content.classList.add("light");
                content.classList.remove("dark");
            }
            
            if(denunciaPage){
                denunciaPage.classList.add("light");
                denunciaPage.classList.remove("dark");
                content.classList.add("light");
                content.classList.remove("dark");
            }
            
        }
        if (radio.checked) {
            console.log(radio.value);
        }

    })
});*/
/*
document.addEventListener("DOMContentLoaded", () => {

    const traducoes = {

        pt: {
            title: "Aliciamento",
            text: "Texto em português"
        },

        en: {
            title: "Grooming",
            text: "English text"
        },

        es: {
            title: "Acoso",
            text: "Texto en español"
        }

    };

    const radios = document.querySelectorAll('input[name="idioma"]');

    function trocarIdioma(idioma) {

        const elementos = document.querySelectorAll("[data-i18n]");

        elementos.forEach(elemento => {

            const chave = elemento.dataset.i18n;

            if (
                traducoes[idioma] &&
                traducoes[idioma][chave]
            ) {

                elemento.textContent =
                    traducoes[idioma][chave];

            }

        });

        localStorage.setItem("idioma", idioma);

    }

    radios.forEach(radio => {

        radio.addEventListener("change", () => {

            trocarIdioma(radio.value);

        });

    });

    const idiomaSalvo =
        localStorage.getItem("idioma") || "pt";

    trocarIdioma(idiomaSalvo);

    radios.forEach(radio => {

        radio.checked =
            radio.value === idiomaSalvo;

    });

});*/
// arrumar a parte dos idiomas

